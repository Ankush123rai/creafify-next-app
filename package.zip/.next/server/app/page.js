(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 1090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 8652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5120);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7328)), "C:\\Users\\LENOVO\\Downloads\\nextjs-tailwind-app-presentation-page-main\\creatify\\src\\app\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4180)), "C:\\Users\\LENOVO\\Downloads\\nextjs-tailwind-app-presentation-page-main\\creatify\\src\\app\\layout.tsx"],
          
        }
      ]
      }.children;
    const pages = ["C:\\Users\\LENOVO\\Downloads\\nextjs-tailwind-app-presentation-page-main\\creatify\\src\\app\\page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    
    
    const originalPathname = "/page"
  

/***/ }),

/***/ 3410:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5192, 23))

/***/ }),

/***/ 7746:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7859))

/***/ }),

/***/ 3880:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5124));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6995));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7859))

/***/ }),

/***/ 5124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8714);
/* harmony import */ var _material_tailwind_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_typed__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8988);
/* __next_internal_client_entry_do_not_use__  auto */ 



function Hero() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative min-h-screen w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                className: "grid !min-h-[49rem] bg-gray-900 px-8",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container mx-auto mt-32 grid h-full w-full grid-cols-1 place-items-center lg:mt-14 lg:grid-cols-2",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    color: "white",
                                    className: "mb-4 text-[2.5rem] font-bold",
                                    children: [
                                        "Let's build the future together ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "starting with your vision."
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "lead",
                                    className: "mb-7 !text-white md:pr-16 xl:pr-28",
                                    children: [
                                        "At Creatify Technologies, we are passionate about transforming ideas into cutting-edge software solutions. At Creatify Technologies, we provide",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_typed__WEBPACK_IMPORTED_MODULE_3__/* .ReactTyped */ .x, {
                                            className: "text-red-700 font-bold",
                                            strings: [
                                                "Modern Websites",
                                                "CRM Development",
                                                "Mobile Applications"
                                            ],
                                            typeSpeed: 40,
                                            backSpeed: 50,
                                            loop: true
                                        }),
                                        ".|"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col gap-2 md:mb-2 md:w-10/12 md:flex-row",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                        size: "lg",
                                        color: "white",
                                        className: "flex justify-center items-center gap-3",
                                        placeholder: "",
                                        onPointerEnterCapture: ()=>{},
                                        onPointerLeaveCapture: ()=>{},
                                        children: "let's Connect"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                            width: 470,
                            height: 576,
                            src: "/image/iphones.png",
                            alt: "team work",
                            className: "col-span-1 my-20 h-full max-h-[30rem] -translate-y-32 md:max-h-[36rem] lg:my-0 lg:ml-auto lg:max-h-[40rem] lg:translate-y-0"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mx-8 lg:mx-16 -mt-24 rounded-xl bg-white p-5 md:p-14 shadow-md",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            placeholder: "",
                            onPointerEnterCapture: ()=>{},
                            onPointerLeaveCapture: ()=>{},
                            variant: "h3",
                            color: "blue-gray",
                            className: "mb-3",
                            children: "Empowering your vision—one innovative solution at a time."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "paragraph",
                            className: "font-normal !text-gray-500 lg:w-5/12",
                            placeholder: "",
                            onPointerEnterCapture: ()=>{},
                            onPointerLeaveCapture: ()=>{},
                            children: "Welcome to Creatify Technologies, where we bring ideas to life with innovative, high-performance software solutions. Our team is dedicated to transforming visions into impactful Android apps and IT solutions that drive success. Let’s create the future of digital, together."
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 6995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VideoIntro": () => (/* binding */ VideoIntro),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_tailwind_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8714);
/* harmony import */ var _material_tailwind_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9976);
/* __next_internal_client_entry_do_not_use__ VideoIntro auto */ 




function VideoIntro() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "p-8",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full container px-5 overflow-hidden rounded-xl relative mx-auto mt-20 max-w-6xl ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-black/25 z-10 absolute w-full h-full inset-0 rounded-xl"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    width: 768,
                    height: 400,
                    src: "/image/Background.png",
                    className: "w-full object-cover scale-110 rounded-xl h-full",
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute top-2/4 left-2/4 -translate-x-2/4 -translate-y-2/4 z-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                        placeholder: "",
                        onPointerEnterCapture: ()=>{},
                        onPointerLeaveCapture: ()=>{},
                        color: "white",
                        className: "rounded-full",
                        size: "lg",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            className: "h-6 w-6"
                        })
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VideoIntro);


/***/ }),

/***/ 7859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "FeatureCard": () => (/* reexport */ FeatureCard),
  "FixedPlugin": () => (/* reexport */ FixedPlugin),
  "Footer": () => (/* reexport */ Footer),
  "InfoCard": () => (/* reexport */ InfoCard),
  "Layout": () => (/* reexport */ Layout),
  "Navbar": () => (/* reexport */ Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/@material-tailwind/react/index.js
var react = __webpack_require__(8714);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js
var XMarkIcon = __webpack_require__(1966);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/24/outline/esm/Bars3Icon.js
var Bars3Icon = __webpack_require__(4832);
;// CONCATENATED MODULE: ./src/components/navbar.tsx





function NavItem({ children , href  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
            as: "a",
            href: href || "#",
            target: href ? "_blank" : "_self",
            variant: "small",
            className: "font-medium",
            placeholder: "",
            onPointerEnterCapture: ()=>{},
            onPointerLeaveCapture: ()=>{},
            children: children
        })
    });
}
function Navbar() {
    const [open, setOpen] = (0,react_.useState)(false);
    const [isScrolling, setIsScrolling] = (0,react_.useState)(false);
    function handleOpen() {
        setOpen((cur)=>!cur);
    }
    (0,react_.useEffect)(()=>{
        window.addEventListener("resize", ()=>window.innerWidth >= 960 && setOpen(false));
    }, []);
    react_default().useEffect(()=>{
        function handleScroll() {
            if (window.scrollY > 0) {
                setIsScrolling(true);
            } else {
                setIsScrolling(false);
            }
        }
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Navbar, {
        fullWidth: true,
        shadow: false,
        blurred: false,
        color: isScrolling ? "white" : "transparent",
        className: "fixed top-0 z-50 border-0",
        placeholder: "",
        onPointerEnterCapture: ()=>{},
        onPointerLeaveCapture: ()=>{},
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container mx-auto flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Typography, {
                        as: "a",
                        href: "/",
                        target: "_blank",
                        variant: "h6",
                        color: isScrolling ? "gray" : "white",
                        className: "flex items-center gap-1",
                        placeholder: "",
                        onPointerEnterCapture: ()=>{},
                        onPointerLeaveCapture: ()=>{},
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                width: 50,
                                height: 30,
                                src: "/logos/creatifyLogo.png",
                                alt: "logo"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                        placeholder: "",
                                        onPointerEnterCapture: ()=>{},
                                        onPointerLeaveCapture: ()=>{},
                                        className: "font-semibold text-[14px]",
                                        color: isScrolling ? "gray" : "white",
                                        children: "Creatify"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                        placeholder: "",
                                        onPointerEnterCapture: ()=>{},
                                        onPointerLeaveCapture: ()=>{},
                                        className: "font-semibold text-[14px]",
                                        color: isScrolling ? "gray" : "white",
                                        children: "Technologies"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: `ml-10 hidden items-center gap-6 lg:flex ${isScrolling ? "text-gray-900" : "text-white"}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                children: "Home"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                children: "About Us"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                children: "Contact Us"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                href: "",
                                children: "Projects"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden gap-2 lg:flex lg:items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                variant: "text",
                                color: isScrolling ? "gray" : "white",
                                size: "sm",
                                placeholder: "",
                                onPointerEnterCapture: ()=>{},
                                onPointerLeaveCapture: ()=>{},
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-brands fa-twitter text-base"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                variant: "text",
                                color: isScrolling ? "gray" : "white",
                                size: "sm",
                                placeholder: "",
                                onPointerEnterCapture: ()=>{},
                                onPointerLeaveCapture: ()=>{},
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-brands fa-facebook text-base"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                variant: "text",
                                color: isScrolling ? "gray" : "white",
                                size: "sm",
                                placeholder: "",
                                onPointerEnterCapture: ()=>{},
                                onPointerLeaveCapture: ()=>{},
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa-brands fa-instagram text-base"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "",
                                target: "_blank",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react.Button, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    color: isScrolling ? "gray" : "white",
                                    size: "sm",
                                    children: "Join Us"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                        variant: "text",
                        color: isScrolling ? "gray" : "white",
                        onClick: handleOpen,
                        className: "ml-auto inline-block lg:hidden",
                        placeholder: "",
                        onPointerEnterCapture: ()=>{},
                        onPointerLeaveCapture: ()=>{},
                        children: open ? /*#__PURE__*/ jsx_runtime_.jsx(XMarkIcon/* default */.Z, {
                            strokeWidth: 2,
                            className: "h-6 w-6"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(Bars3Icon/* default */.Z, {
                            strokeWidth: 2,
                            className: "h-6 w-6"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react.Collapse, {
                open: open,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mx-auto mt-4 rounded-lg border-t border-blue-gray-50 bg-white px-6 py-5",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "flex flex-col gap-4 text-blue-gray-900",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                    children: "Home"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                    children: "About Us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                    children: "Contact Us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(NavItem, {
                                    href: "",
                                    children: "Projects"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-4 flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "text",
                                    color: "gray",
                                    size: "sm",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-brands fa-twitter text-base"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "text",
                                    color: "gray",
                                    size: "sm",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-brands fa-facebook text-base"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "text",
                                    color: "gray",
                                    size: "sm",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-brands fa-instagram text-base"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "",
                                    target: "_blank",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react.Button, {
                                        placeholder: "",
                                        onPointerEnterCapture: ()=>{},
                                        onPointerLeaveCapture: ()=>{},
                                        color: "gray",
                                        size: "sm",
                                        className: "ml-auto",
                                        children: "Join Us"
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const navbar = ((/* unused pure expression or super */ null && (Navbar)));

;// CONCATENATED MODULE: ./src/components/footer.tsx
/* __next_internal_client_entry_do_not_use__ Footer auto */ 


const LINKS = [
    "About Us",
    "Careers",
    "Press",
    "Blog",
    "Pricing"
];
const CURRENT_YEAR = new Date().getFullYear();
function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "mt-10 bg-gray-900 px-8 pt-12",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap justify-center gap-8 md:justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-center md:text-left",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Typography, {
                                    as: "a",
                                    href: "/",
                                    target: "_blank",
                                    variant: "h6",
                                    color: "white",
                                    className: "flex items-center gap-1",
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            width: 50,
                                            height: 30,
                                            src: "/logos/creatifyLogo.png",
                                            alt: "logo"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                                    className: "font-semibold text-[14px]",
                                                    color: "white",
                                                    placeholder: "",
                                                    onPointerEnterCapture: ()=>{},
                                                    onPointerLeaveCapture: ()=>{},
                                                    children: "Creatify"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                                    className: "font-semibold text-[14px]",
                                                    color: "white",
                                                    placeholder: "",
                                                    onPointerEnterCapture: ()=>{},
                                                    onPointerLeaveCapture: ()=>{},
                                                    children: "Technologies"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    color: "white",
                                    className: "mb-12 font-normal",
                                    children: "The reward for getting on the stage is fame."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "flex flex-wrap items-center justify-center md:justify-start",
                                    children: LINKS.map((link, idx)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                                placeholder: "",
                                                onPointerEnterCapture: ()=>{},
                                                onPointerLeaveCapture: ()=>{},
                                                as: "a",
                                                href: "#",
                                                color: "white",
                                                className: `py-1 font-medium transition-colors ${idx === 0 ? "pr-3" : "px-3"}`,
                                                children: link
                                            })
                                        }, link))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-8 w-full md:mt-0 md:w-auto",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "h6",
                                    color: "white",
                                    className: "mb-3",
                                    children: "Get the app"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col gap-2",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Button, {
                                            color: "white",
                                            className: "flex items-center justify-center",
                                            placeholder: "",
                                            onPointerEnterCapture: ()=>{},
                                            onPointerLeaveCapture: ()=>{},
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    width: 256,
                                                    height: 256,
                                                    src: "/logos/logo-apple.png",
                                                    className: "-mt-0.5 mr-2 h-6 w-6",
                                                    alt: "ios"
                                                }),
                                                "App Store"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Button, {
                                            color: "white",
                                            className: "flex items-center justify-center",
                                            placeholder: "",
                                            onPointerEnterCapture: ()=>{},
                                            onPointerLeaveCapture: ()=>{},
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    width: 256,
                                                    height: 256,
                                                    src: "/logos/logo-google.png",
                                                    className: "-mt-0.5 mr-2 h-6 w-6",
                                                    alt: "ios"
                                                }),
                                                "Google Play"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-16 flex flex-wrap items-center justify-center gap-y-4 gap-x-8 border-t border-gray-700 py-7 md:justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Typography, {
                            color: "white",
                            className: "text-center font-normal opacity-75",
                            placeholder: "",
                            onPointerEnterCapture: ()=>{},
                            onPointerLeaveCapture: ()=>{},
                            children: [
                                "\xa9 ",
                                CURRENT_YEAR,
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://www.material-tailwind.com",
                                    target: "_blank",
                                    children: "Creatify Technologies,"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "https://www.creative-tim.com",
                                    target: "_blank",
                                    children: "All Rights Reserved"
                                }),
                                "."
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "text",
                                    color: "white",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-brands fa-twitter text-2xl not-italic opacity-75"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "text",
                                    color: "white",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-brands fa-linkedin text-2xl not-italic opacity-75"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react.IconButton, {
                                    placeholder: "",
                                    onPointerEnterCapture: ()=>{},
                                    onPointerLeaveCapture: ()=>{},
                                    variant: "text",
                                    color: "white",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa-brands fa-facebook text-2xl not-italic opacity-75"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const footer = ((/* unused pure expression or super */ null && (Footer)));

;// CONCATENATED MODULE: ./src/components/layout.tsx
/* __next_internal_client_entry_do_not_use__ Layout auto */ 


function Layout({ children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(react.ThemeProvider, {
        children: children
    });
}
/* harmony default export */ const layout = ((/* unused pure expression or super */ null && (Layout)));

;// CONCATENATED MODULE: ./src/components/feature-card.tsx


function FeatureCard({ icon: Icon , title , children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(react.Card, {
        placeholder: "",
        onPointerEnterCapture: ()=>{},
        onPointerLeaveCapture: ()=>{},
        color: "transparent",
        shadow: false,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.CardBody, {
            placeholder: "",
            onPointerEnterCapture: ()=>{},
            onPointerLeaveCapture: ()=>{},
            className: "grid justify-start",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mb-4 grid h-12 w-12 place-content-center rounded-lg bg-gray-900 p-2.5 text-left text-white",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                        className: "h-6 w-6"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                    placeholder: "",
                    onPointerEnterCapture: ()=>{},
                    onPointerLeaveCapture: ()=>{},
                    variant: "h5",
                    color: "blue-gray",
                    className: "mb-2",
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                    placeholder: "",
                    onPointerEnterCapture: ()=>{},
                    onPointerLeaveCapture: ()=>{},
                    className: " font-normal !text-gray-500",
                    children: children
                })
            ]
        })
    });
}
/* harmony default export */ const feature_card = ((/* unused pure expression or super */ null && (FeatureCard)));

;// CONCATENATED MODULE: ./src/components/info-card.tsx



function InfoCard({ title , children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(react.Card, {
        placeholder: "",
        onPointerEnterCapture: ()=>{},
        onPointerLeaveCapture: ()=>{},
        color: "transparent",
        shadow: false,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.CardBody, {
            placeholder: "",
            onPointerEnterCapture: ()=>{},
            onPointerLeaveCapture: ()=>{},
            className: "grid px-0",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                    placeholder: "",
                    onPointerEnterCapture: ()=>{},
                    onPointerLeaveCapture: ()=>{},
                    variant: "h2",
                    color: "blue-gray",
                    className: "mb-2",
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                    placeholder: "",
                    onPointerEnterCapture: ()=>{},
                    onPointerLeaveCapture: ()=>{},
                    className: " font-normal",
                    children: children
                })
            ]
        })
    });
}
/* harmony default export */ const info_card = ((/* unused pure expression or super */ null && (InfoCard)));

;// CONCATENATED MODULE: ./src/components/fixed-plugin.tsx
/* __next_internal_client_entry_do_not_use__ FixedPlugin auto */ 

// import { Button } from "@material-tailwind/react";
function FixedPlugin() {
    return /*#__PURE__*/ jsx_runtime_.jsx("a", {
        href: "",
        target: "_blank",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            // color="white"
            // size="sm"
            className: "!fixed bottom-4 right-4 flex gap-1 pl-2 items-center border border-blue-gray-50",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    width: 128,
                    height: 100,
                    className: "w-5 h-5",
                    alt: "Material Tailwind",
                    src: "/logos/creatifyLogo.png"
                }),
                " ",
                "Creatify Technologies"
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/index.ts
/* __next_internal_client_entry_do_not_use__ *,*,*,*,*,*,* auto */ 








/***/ }),

/***/ 3132:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(5985);
module.exports = createProxy("C:\\Users\\LENOVO\\Downloads\\nextjs-tailwind-app-presentation-page-main\\creatify\\src\\app\\hero.tsx");


/***/ }),

/***/ 4180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   "metadata": () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_300_400_500_700_900_display_swap_variableName_roboto___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4721);
/* harmony import */ var next_font_google_target_css_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_300_400_500_700_900_display_swap_variableName_roboto___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_300_400_500_700_900_display_swap_variableName_roboto___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5553);
/* harmony import */ var _globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9554);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_components__WEBPACK_IMPORTED_MODULE_2__);




const metadata = {
    title: "Creatify Technologies"
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("head", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "stylesheet",
                        href: "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css",
                        integrity: "sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==",
                        crossOrigin: "anonymous",
                        referrerPolicy: "no-referrer"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "shortcut icon",
                        href: "/favicon.png",
                        type: "image/png"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                className: (next_font_google_target_css_path_src_app_layout_tsx_import_Roboto_arguments_subsets_latin_weight_300_400_500_700_900_display_swap_variableName_roboto___WEBPACK_IMPORTED_MODULE_3___default().className),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components__WEBPACK_IMPORTED_MODULE_2__.Layout, {
                    children: [
                        children,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__.FixedPlugin, {})
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 7328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Campaign)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./src/components/index.ts
var components = __webpack_require__(9554);
// EXTERNAL MODULE: ./src/app/hero.tsx
var hero = __webpack_require__(3132);
var hero_default = /*#__PURE__*/__webpack_require__.n(hero);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(5985);
;// CONCATENATED MODULE: ./src/app/video-intro.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\LENOVO\Downloads\nextjs-tailwind-app-presentation-page-main\creatify\src\app\video-intro.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const video_intro = (proxy.default);

const e0 = proxy["VideoIntro"];

;// CONCATENATED MODULE: ./src/app/page.tsx
// components


// sections


function Campaign() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components.Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx((hero_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(video_intro, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components.Footer, {})
        ]
    });
}


/***/ }),

/***/ 9554:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ *,*,*,*,*,*,* auto */ const { createProxy  } = __webpack_require__(5985);
module.exports = createProxy("C:\\Users\\LENOVO\\Downloads\\nextjs-tailwind-app-presentation-page-main\\creatify\\src\\components\\index.ts");


/***/ }),

/***/ 5553:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [678], () => (__webpack_exec__(6551)));
module.exports = __webpack_exports__;

})();